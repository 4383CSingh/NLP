import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import pyqtSlot, QSize
import DisplayVideo
import GetSentence

from PIL import Image

#initialise the pyqt, careful with the parameteres passes
class App(QWidget):
    def __init__(self, lstOfSent):
        super().__init__()
        self.title = 'PyQt5 button - pythonspot.com'
        self.left = 0
        self.top = 0
        self.width = 500
        self.height = 500
        #if u want to replce the text with word cloud

        # self.setIcon(QIcon('/Users/chandinisingh/Desktop/beehappy.png'))
        self.initUI(lstOfSent)

#for buttons
#now fixed for four buttons, later modify the code
    def initUI(self, lstOfSent):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.data = lstOfSent
        fileName = "/Users/chandinisingh/PycharmProjects/IndependentStudy/UserInterface/ProceessXML/testplot9.png"

        #
        # im = Image.open(fileName)
        # im = im.rotate(90)
        # f =im.save_as('abc.png')

        # icon = QIcon(fileName)

        button = QPushButton('', self)


        width = self.width
        height = self.height

        width1 = 100
        height1 = 100


        # transcribedAudio = 'PyQt5 button or watever'

        #later change this
        start = 10
        end = 20
        # sent = GetSentence.getUserTimeSent(start, end), if
        # transcribedAudio = GetSentence.processXML(start, end)


        width = 500
        height = 125

        #set the button color according to sensitivity

        sButt0n1 =lstOfSent[0][0]
        col= getColor(lstOfSent[0][3])

        button1 = QPushButton( sButt0n1, self )

        button1.resize(width, height)
        button1.setStyleSheet("background-color:" +col+";")
        button1.move(0, 0)#move according to where the buttons should be on the window
        button1.clicked.connect(self.on_click1)

        #lstOfSent[1][0] - first list
        sButt0n2 =lstOfSent[1][0]
        col= getColor(lstOfSent[1][3])

        button2 = QPushButton( sButt0n2, self )

        button2.resize(width, height)
        button2.setStyleSheet("background-color:" +col+";")
        button2.move(0, 125)

        # button1.clicked.connect(self.on_click2(lstOfSent[0][1],lstOfSent[0][2]))
        button2.clicked.connect(self.on_click2)#avoid using parameters with onclick method

        # lstOfSent[1][0] - first list
        sButt0n3 = lstOfSent[2][0]
        col = getColor(lstOfSent[2][3])

        button3 = QPushButton(sButt0n3, self)

        button3.resize(width, height)
        button3.setStyleSheet("background-color:" + col + ";")
        button3.move(0,250)

        button3.clicked.connect(self.on_click3)

        sButt0n4 = lstOfSent[3][0]
        col = getColor(lstOfSent[3][3])

        button4 = QPushButton(sButt0n4, self)
        button4.resize(width, height)
        button4.setStyleSheet("background-color:" + col + ";")
        button4.move(0, 375)
        button4.clicked.connect(self.on_click4 )

        #
        # button4 = QPushButton(self)
        # button4.resize(width, height)
        # button4.move(0, 250)

        # button = QPushButton(transcribedAudio, self)
        # #hover
        # # button.setToolTip('This is an example button')
        # # button.setIconSize(QSize(width, height))
        # # button.setIcon(icon)
        # button.resize(width,height)
        # # button.setFixedSize(1, 1, 5, 1)
        # #color of the sentiment in the backgraound , and the picture is word cloud
        #
        # #the sensitivity is here
        # button.setStyleSheet("background-color: rgb(0,200,0);")
        # button.move(0, 0)
        # button.clicked.connect(self.on_click)


        self.show()



#onclick events for buttons
    @pyqtSlot()
    def on_click1(self):
        getTimeForButton1(self.data)

    def on_click2(self):
        getTimeForButton2(self.data)

    def on_click3(self):
        getTimeForButton3(self.data)

    def on_click4(self):
        getTimeForButton4(self.data)


#colors - sentivity
def getColor(sensitivityScore):
    col =""
    # print("sensitivityScore",sensitivityScore)
    if(-0.5 < sensitivityScore <  0.0):
        return "rgb(220,0, 0)"#red highly negative
    elif(sensitivityScore <= -0.5):
        return  "rgb(250,0, 0)"
    elif ( 0.0 <= sensitivityScore < 0.5):
        return "rgb(0,220, 0)"
    elif(sensitivityScore >= 0.5):
        return "rgb(0,250, 0)"

# colors - sentivity
def getColorVideoFrame(sensitivityScore):
    # print("sensitivityScore",sensitivityScore)
    if (-0.5 < sensitivityScore < 0.0):
        return [220,0, 0]  # red highly negative
    elif (sensitivityScore <= -0.5):
        return [250,0, 0]
    elif (0.0 <= sensitivityScore < 0.5):
        return [0,220, 0]
    elif (sensitivityScore >= 0.5):
        return [0,250, 0]

#get the time for displaying the video
def getTimeForButton1(lstOfSent):
    start = lstOfSent[0][1]
    end = lstOfSent[0][2]
    videoFile = "/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/video2.mp4"
    colVal = getColorVideoFrame(lstOfSent[0][3])
    DisplayVideo.showVdeo(videoFile, start, end, colVal)

    # DisplayVideo.showVdeo(videoFile, start, end)

def getTimeForButton2(lstOfSent):
    start = lstOfSent[1][1]
    end = lstOfSent[1][2]
    videoFile =  "/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/video2.mp4"
    colVal = getColorVideoFrame(lstOfSent[1][3])
    DisplayVideo.showVdeo(videoFile, start, end, colVal)

def getTimeForButton3(lstOfSent):
    start = lstOfSent[2][1]
    end = lstOfSent[2][2]
    videoFile =  "/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/video2.mp4"
    colVal = getColorVideoFrame(lstOfSent[2][3])
    DisplayVideo.showVdeo(videoFile, start, end, colVal)

def getTimeForButton4(lstOfSent):
    start = lstOfSent[3][1]
    end = lstOfSent[3][2]
    videoFile =  "/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/video2.mp4"
    colVal = getColorVideoFrame(lstOfSent[3][3])
    DisplayVideo.showVdeo(videoFile, start, end, colVal)


def processSentences (lstOfSent):
    app = QApplication(lstOfSent)
    ex = App(lstOfSent)
    sys.exit(app.exec_())


#perform --
def callButton1():
    print()

if __name__ == '__main__':
    lstOfSent =[]
    processSentences(lstOfSent)
    # app = QApplication(sys.argv)
    # ex = App()
    # sys.exit(app.exec_())