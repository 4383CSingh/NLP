from textblob import TextBlob
from textblob.sentiments import NaiveBayesAnalyzer

#later to be replace by curator/ stanford core nlp
text = '''

The titular threat of The Blob has always struck me as the ultimate movie
monster: an insatiably hungry, amoeba-like mass able to penetrate
virtually any safeguard, capable of--as a doomed doctor chillingly
describes it--"assimilating flesh on contact.
Snide comparisons to gelatin be damned, it's a concept with the most
devastating of potential consequences, not unlike the grey goo scenario
proposed by technological theorists fearful of
artificial intelligence run rampant.
I really love Red color. I hate green.

'''

blob = TextBlob(text)
blob.tags
blob.noun_phrases


#gtet the sentiment
def getSentiment(sentence):
    blob = TextBlob(sentence)
    return blob.sentiment.polarity