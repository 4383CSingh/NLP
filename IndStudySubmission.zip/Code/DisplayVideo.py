
import cv2
import time


#display video with given start time, end and the color for the frame according to sensitivity
def showVdeo(videoFile,   start, end ,colVal):
    # def showVdeo(videoFile,   start, end ):

    # print("Dispalying the video",start, end)
    cap = cv2.VideoCapture(videoFile)
    length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    # displaying with the exact time for the video
    fps = cap.get(cv2.CAP_PROP_FPS)

    # print("Total number of fames in the video :", length )
    # print("The number of frames in  one soecond", fps)
    if fps > 0:
        waitPerFrameInMillisec = int(1 / fps * 1000 / 1)

        # print("Total duration of the video is :", length / fps, " seconds")

    countStartFrame = start * fps
    countLastFrame = end * fps
    count = 0
    playSecond = 5
    # as the number of frames the loop runs so many times
    start_time = time.time()
    # print("--- started %s seconds ---",start_time )
    bordersize = 10

    while (cap.isOpened()):

        ret, frame = cap.read()
        if frame is None:
            break
        if count >= countLastFrame:
            break
        if (count >= (countStartFrame // 1)):
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            cv2.imshow('Playing Video', gray)
            # borderedFrame = cv2.copyMakeBorder(frame, 15, 15, 15, 15, cv2.BORDER_CONSTANT, value=[0, 200, 0])
            borderedFrame = cv2.copyMakeBorder(frame, 15, 15, 15, 15, cv2.BORDER_CONSTANT, value=colVal)
            # cv2.imshow('frame', gray)
            cv2.imshow('Playing Video', borderedFrame)

            cv2.waitKey(waitPerFrameInMillisec)

        count += 1
    # cv2.imshow("frame", frame)
    # borderedFrame = cv2.copyMakeBorder(frame, 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=[0, 200, 200])
    # cv2.imshow("bordered frame", borderedFrame)
    # print("--- ended %s seconds ---" % (time.time() - start_time))
    # print("the number for times loop run", count)
    cap.release()
    cv2.destroyAllWindows()


def main():
    videoFile = '/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/video2.mp4'

    start= int(input("enter the start time of the frame "))
    end = int(input("enter  end time"))
    colVal =[0,0,0]#change acc to sensitivity

    showVdeo(videoFile,  start, end ,colVal)

if __name__ == "__main__":
        main()
