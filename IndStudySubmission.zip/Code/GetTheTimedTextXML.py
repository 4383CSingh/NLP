from bs4 import BeautifulSoup


#process the xml file
def processXML(transcriptFile):
    infile = open(transcriptFile, "r")
    contents = infile.read()
    soup = BeautifulSoup(contents, 'xml')
    return soup

def getDataForEachSentences(soup):

    d = {}
    count = 1
    #access only the text tags
    #key is the count, and the value is a list of
    #startTime, duration, and the sentence in the order ->[0,1,2] in the list
    for tags in getTextTags(soup):
        startTime = getStartTime(tags)
        duration = getDuration(tags)
        sentence = replaceStr(tags.text)
        d[count] = [startTime, duration, sentence]
        count+=1

    return d

def replaceStr(sentence):
    s = '&#39'#this might change, xml values
    sentence =  sentence.replace(s, '')
    return sentence

def getAllTags(soup):
    return(soup.find_all(True))

def getStartTime(textTags):
    return textTags.get('start')

def getDuration(textTags):
    return textTags.get('dur')


def getTextTags(soup):
    #but we are interested in text tags
    textTags =  soup.find_all("text")
    return textTags


def getTheTranscript(soup):
    transcript = soup.get_text()
    s = '&#39'#this might change, xml values
    transcript =  transcript.replace(s, '')
    return transcript


def sampleData(sentDict):
    # print(len(sentDict)/2)
    samplingSize = 2
    samples = len(sentDict)/samplingSize
    print(samples)
    count =1
    s=""
    slist = []
    for k in sentDict:
        if count !=samples:
            s += sentDict[k][2]
            count += 1
        else:
            slist.append(s)
            count = 1
            s =""

    count =0
    for s in slist:
        count  +=1
        print("count-", count)
        print(s)



#consider a start time less than 5 minutes and then progress

def main():
    # transcriptFile = input("Enter the transcript file")
    transcriptFile = "/Users/chandinisingh/PycharmProjects/IndependentStudy/UserInterface/ProceessXML/Imagine.xml"
    # transcriptFile = "/Users/chandinisingh/PycharmProjects/IndependentStudy/UserInterface/ProceessXML/timedtext.xml"

    soup = processXML(transcriptFile)
    transcript = getTheTranscript(soup)
    # print(transcript)

    sentDict = getDataForEachSentences(soup)
    sampleData(sentDict)
    # print(sentDict)

if __name__ == '__main__':
    main()
