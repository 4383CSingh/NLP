import GetTheTimedTextXML
# import StopWords
# import SampleWordCloud
import matplotlib.pyplot as plt

#this script process the time texted xml, and different from the text grid processing

def processXML(start, end):
    # transcriptFile = input("Enter the transcript file")
    transcriptFile = "/Users/chandinisingh/PycharmProjects/IndependentStudy/UserInterface/ProceessXML/Imagine.xml"
    # transcriptFile = "/Users/chandinisingh/PycharmProjects/IndependentStudy/UserInterface/ProceessXML/timedtext.xml"

    # minutes = input("Enter the max time")
    seconds =1*60
    soup = GetTheTimedTextXML.processXML(transcriptFile)
    transcript = GetTheTimedTextXML.getTheTranscript(soup)
    sentDict = GetTheTimedTextXML.getDataForEachSentences(soup)

    sentence = getUserTimeSent(sentDict, start, end )

    return sentence
    # print(sentDict)
    exit(0)



    sentDict = getSentenceWordCloud(sentDict, seconds)
    showPlots(sentDict, 20)


def getUserTimeSent(sentDict , start , end ):

    count = 1
    sentence = ""
   # end + 1 - we assume +1, -1 second
    for k in sentDict:
        if(float(sentDict[k][0]) <= end and float(sentDict[k][0]) >= start) :
            sentence += " "+ sentDict[k][2]

    # print(sentence)

    return sentence


def showPlots(sentDict, seconds):
    count =1
    for k in sentDict:
        if float(sentDict[k][0]) <= seconds:
            plt.imshow(sentDict[k][3])
            plt.axis("off")
            plt.savefig('testplot'+str(count)+'.png')
            # Image.open('testplot.png').save('testplot.jpg', 'JPEG')
            count += 1
            plt.show()

def getSenetnces (sentDict, seconds):
    for k in sentDict:
        if float(sentDict[k][0]) <= seconds:
            # print(sentDict[k][0])
            s = sentDict[k][2]


def getSentenceWordCloud(sentDict, seconds):
    #get only the sentences
    #first remove

    for k in sentDict:
        if float(sentDict[k][0]) <= seconds:
            # print(sentDict[k][0])
            s = sentDict[k][2]
            s = StopWords.removeStopWords(s)
            wordCloud = SampleWordCloud.showWordCloud(s)
            sentDict[k].append(wordCloud)
    return sentDict

def getWordCloud():
    print()

def main():
    start = int(input ("Enter the start time in seconds"))
    end = int(input ("Enter the end time in seconds"))
    processXML(start, end)

if __name__ == '__main__':
    main()