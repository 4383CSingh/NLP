# import ConvertingWAVtoText
# import SentimentAnanlysis
# import DisplaySentiment
import DisplayVideo
import SampleTextBlob
import ButtonSample

import ProcessTextGrid

#returns the sentiment of teh sentence
def sentimentAnalysis(text):
    sentiment = SentimentAnanlysis.textAnalysis(text)


#conv the wav file format to wav using the specifc api
def convertWavToText(wavFile):
    print("Dispalying text..")
    text = ConvertingWAVtoText.conText(wavFile)

    # print(text)
    return text


#put everything toegther
def main():
    # videoFile, wavFile =askUserInputFiles()

#remove this
    # wavFile = '/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/audio2.wav'
    videoFile = "/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/xyz.mp4"
    # processInput(videoFile, wavFile)
    # text = convertWavToText(wavFile)
    # sentiment = sentimentAnalysis(text)

    # before moving ahead get the text grid - now we have a text grid file, later automate this
    textGridFilePath=  "/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/TextGrid.csv"
    start = int(input("Enter the start time in seconds"))
    end = int(input("Enter the end time in seconds"))
    listOfSen = getSenetncesSentiments(textGridFilePath, start, end)

    # print(listOfSen)
    ButtonSample.processSentences(listOfSen)



# get the sentences, along with teh senti of using a text grid
#this has to be replaced according- if using time textxml
#  or any block which gives the textual info with the time stamps
def getSenetncesSentiments(textGridFilePath,start, end):
    #for now i divide the time into 4 segments
    time = list(range(start, end, (end // 4)))
    time.append(end)

    listOfSen =[]
    for i in range(len(time)-1):
        l=[]
        start = time[i]
        end = time[i+1]
        s = ProcessTextGrid.processTextGrid(textGridFilePath, start, end)
        sentiment = SampleTextBlob.getSentiment(s)
        l.append(s)
        l.append(start)
        l.append(end)
        l.append(sentiment)
        listOfSen.append(l)

    return listOfSen


def askUserInputFiles():
    videoFile = input("Enter the path to video")
    wavFile =input("Enter the path to wav File")
    return videoFile, wavFile



#sometimes the cloud speech api, doesnt return the results

if __name__ == "__main__":
   main()


