
import pandas as pd
import math

#process the text grid - obtained from forced aligner
#to get the duration of the words and manipulate it accordingly
 #you can also use df['column_name']

 #note about nan values for time -we consider the latest time, and append the word to this latest time
 #if words are nan for the given time we donot consider those and dont add them to dictionary
def getDuration(textGrid):
    df = pd.read_csv(textGrid)
    #list has list[0]  - start time  list [1] - word
    textGridDict = {}
    sizeOfDataFrame = df["words_start"].size
    count = 0
    for i in range(sizeOfDataFrame):
        time = getTime(df, i)
        word = getWord(df, i)
        if time is not None and word is not None:
            count +=1
            addValueToDictionary(textGridDict, count, time, word)
        elif(time is None and word is not None):#wwe dont inc time here
            prev = textGridDict[count][1]
            textGridDict[count][1] = prev+ " "+word
            # print("after : ", textGridDict[count][1] )
    return textGridDict



#getSentence
def getSentence(textGridDict,start, end):
        sentence = ""
        # end + 1 - we assume +1, -1 second
        for k in textGridDict:
            if (float(textGridDict[k][0]) <= end and float(textGridDict[k][0]) >= start):
                sentence += " " + textGridDict[k][1]

        return sentence
#addValueToDictionary to keep a track of the sentences/words, time
def addValueToDictionary(textGridDict,count,time,word  ):
    l =[]
    l.append(time)
    l.append(word)
    textGridDict[count] = l


#getTime from the datafrmae
def getTime(df, i):
    if not( math.isnan(df["words_start"][i])):
        return df["words_start"][i]
#getWord for datafrmae
def getWord(df, i):
    if ((type(df["words_word"][i]) == str) and (len(df["words_word"][i]) >= 1)):
        return df["words_word"][i]

def processTextGrid(fileName,  start, end):
    textGridDict = getDuration(fileName)
    # start = int(input("Enter the start time in seconds"))
    # end = int(input("Enter the end time in seconds"))
    sentence = getSentence(textGridDict, start, end)
    return sentence


def main():
    fileName = input("Enter the text grid name")
    fileName = "/Users/chandinisingh/Desktop/IndependentStuy/SampleVideoFile/TextGrid.csv"
    textGridDict = getDuration(fileName)
    start = int(input("Enter the start time in seconds"))
    end = int(input("Enter the end time in seconds"))
    sentence = getSentence(textGridDict, start, end)

if __name__ == '__main__':
    main()

